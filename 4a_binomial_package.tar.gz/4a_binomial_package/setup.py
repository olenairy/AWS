from setuptools import setup

setup(name='distributions',
      version='0.2',
      description='Gaussian  and Binomial distributions',
      packages=['distributions'],
      zip_safe=False)
